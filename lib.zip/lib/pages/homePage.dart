import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_bloc_tutorial/cubit/counter_cubit.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.title});

  final String title;

  @override
  State<HomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<HomePage> {
  // int _counter = 0;

  // void _incrementCounter() {
  //   setState(() {
  //     _counter++;
  //   });
  // }

  // Always store instance of a class which you going to use
  // so that you not create multiple instances and cause issues
  // like you updating the value but its get updated in different instance
  CounterCubit counterCubitInstance = CounterCubit();


  @override
  Widget build(BuildContext context) {

    // Storing counterCubitInstance.state in a variable
    int counter = counterCubitInstance.state;

    print("\n=== Whole widget build ===\n");

    return Scaffold(
      backgroundColor: const Color.fromARGB(249, 34, 34, 34),
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 124, 77, 255)  ,

        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: .center,
          children: [
            const Text('You have pushed the button this many times:'),

            BlocBuilder<CounterCubit,int>(
              // BlocBuilder of type CounterCubit and state of type int

              //  ============================================

              // we need to pass our bloc just like in provider we tell which
              // provider same like that we tell which bloc : we going to use,

              bloc: counterCubitInstance,

              builder: (context,counter) { // the value we giving here is "counter"" value

                print("=== Text Rebuilt ===");

                return Text(
                  '$counter',
                  style: TextStyle(
                    color: Colors.white ,
                    fontSize: 35
                  ),
                );
              }
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        // onPressed: () {
        //   counterCubitInstance.increment();
        //   setState(() { 
            
        //   });
          
        //   we dont want to use setState to update the ui
        //   we will use a listner named BlocBuilder
        // },

        onPressed: () => counterCubitInstance.increment(),

        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ),
    );
  }
}
