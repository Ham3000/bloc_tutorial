import 'package:flutter/material.dart';

class IncrementDecrementPage extends StatelessWidget {
  const IncrementDecrementPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Row(
          mainAxisAlignment: .center,
          crossAxisAlignment: .center,
          children: [
            IconButton(
              onPressed: () {},
              icon: Icon(Icons.add,size: 30,)
            ),

            IconButton(
              onPressed: () {},
              icon: Icon(Icons.remove,size: 30,)
            ),
          ],
        ),
      ),
    );
  }
}