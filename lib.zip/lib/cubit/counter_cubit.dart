import 'package:flutter_bloc/flutter_bloc.dart';

class CounterCubit extends Cubit<int>{

  // Cubit<State_DataType> if not define <> then its dynamic

  // Cubit is an abstract class means we need to follow the instruction
  // or structure defined in cubit class
  // 
  // It has a constructor requirnment means you neeed to create a 
  // constructor in each class which inheriting Cubit class
  // and its value need to be passed from the child class to parent class

  //  what value we need to pass in the constructor ?
  //  => Cubit(State initialState) : super(initialState);
  //
  //   we need to pass initialState of this CounterCubit class
  //   so [initial] state will be 0 since our counter start from 0
  //   


  // Constructor
  // CounterCubit() : super( initial state)

  CounterCubit():super(0);


  // increment funtion and notify all the listners
  void increment(){
    //  we just want to update the state so do state = whatever updation
    // but it will not work since state is not a setter its a getter
    // and a getter cannnot be changed
    //
    //  because of this another funtion is created in bloc which is 
    //  emit( )
    //
    //  emit( ) update the state to provided state
    //


    // state = state+1;  will not work


    // print("Before update $state");
    emit(state + 1); 
    // print("After update $state\n");
    // this will update the state to provided state and notify all 
    // the listners
  }

}